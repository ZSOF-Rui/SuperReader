# 卡阅 Windows（桌面切片）

- 普通版本：`1.1.0-preview2`
- 开发版：`1.1.0-dev1`（额外提供手机读卡桥接）
- 定位：Windows 10/11 x64 上的**只读** PC/SC 读卡工具
- 状态：可运行、可打包；**尚未在真实读卡器与真实银行卡上验收**
- 构建日期：2026-10-31

## 它能做什么

把银行卡放在 USB 读卡器上，读取芯片公开的 EMV/PBOC 应用信息：

- 枚举 PC/SC 读卡器、连接卡片、显示 ATR 与协议
- 选择 PPSE（`2PAY.SYS.DDF01`），列出支付应用；PPSE 无响应时按常见 AID 顺序探测
- 读取应用公开数据：应用标签、卡号（界面默认掩码）、有效期、持卡人、应用货币、电子现金余额、AIP、AFL、记录数量
- 只读 APDU 控制台：可手工发送 SELECT / READ BINARY / READ RECORD / GET RESPONSE / GET DATA / GPO
- 后台检查卡片是否离开读卡器，离开后自动断开
- 命令行诊断：`--list-terminals`、`--read`、`--selftest`、`--verbose`

**开发版额外提供**：

- 「手机读卡」：调用同一局域网内的 Android 开发版，用手机 NFC 读卡
- 手机只回传脱敏诊断文本；电脑不能发送 APDU，也不能指定读哪个应用或文件

它**不能**做：

- 写卡、圈存、脱机认证、交易、克隆、模拟卡片
- 八达通 / Suica（FeliCa 需要 Sony SDK 与授权）
- 悠游卡（MIFARE Classic 不在 PC/SC 标准内）
- 护照 / 港澳台通行证（桌面切片未实现 BAC/PACE 与 DG 读取）
- 识别发卡行与卡产品名（桌面切片没有携带 Android 的 BIN 与产品名数据）

## 视觉风格

1.1.0 起按 Android 正式版的「本风格」统一：

- 松绿主色 `#0B6B5D`、深松绿 `#06483F`、纸感底色 `#F3F5F2`、琥珀强调 `#B45309`
- 圆角「阅」品牌标与同风格应用图标
- 表格/卡片 16px 圆角、细描边、单一栏头；不再使用蓝色渐变
- 当前桌面版只提供浅色主题；深色主题未实现

## 手机读卡桥接（仅开发版）

### 手机端

1. 安装 Android 开发版 `1.7.0-dev2`，打开「设置 → 手机读卡桥接」
2. 点「开启局域网桥接」；页面会显示 `http://手机IP:端口` 与 8 位配对码
3. 保持该页面在前台；锁屏、切到后台或离开页面会自动停止监听

开发版为了桥接声明 `INTERNET` 权限；正式版与预览版没有该权限。

### 电脑端

1. 运行开发版 `SuperReaderWindowsDev.exe`
2. 点标题栏右侧「手机读卡」，填写手机地址、端口与配对码
3. 点「等待手机贴卡」，把卡片贴近手机背面
4. 手机读取完成后，电脑显示脱敏诊断文本，可复制

### 协议与边界

- 传输：HTTP/1.1，默认端口 `8848`（被占用时依次尝试 `8849–8857`）
- 端点：`GET /status`、`GET /scan?timeout=30`（长轮询）、`GET /last`
- 认证：所有请求都要求 `X-SuperReader-Token` 头或 `token` 查询参数，配对码每次启动随机生成
- 网络：只接受回环地址与局域网地址（`isSiteLocalAddress`）；不监听公网路由
- 请求：只接受 GET；没有 APDU 透传、没有写卡/消费/圈存端点
- 载荷：手机端复用诊断导出文本，卡号与证件号保持脱敏；文本包含公开字段、交易与 APDU 记录，请勿公开分享
- 生命周期：手机应用进入后台即停止监听；Windows 端等待 30 秒无卡则超时

## 硬件与系统

- Windows 10/11 x64
- 一台支持 ISO 14443-4 / ISO 7816 的 PC/SC 读卡器，例如 ACR1252U、ACR122U（PC/SC 模式）
- 读卡器驱动安装正常，Windows 智能卡服务（`SCardSvr`）可用
- 只支持短 APDU（命令不超过 261 字节）；不发送扩展长度 APDU
- 接触式银行卡可直接插入接触式读卡器；非接触银行卡需读卡器支持 ISO-DEP

> 桌面版没有内置 NFC，不能像手机一样“贴一下”；读卡器与驱动是硬前置条件。手机桥接是开发版替代路径。

## 运行

构建后会得到免安装目录与压缩包：

```
dist/windows/SuperReader-Windows-1.1.0-preview2.zip
  SuperReaderWindows.exe          图形界面
  SuperReaderWindowsCLI.exe       命令行诊断（控制台子系统）
  SuperReaderWindows-console.bat  命令行诊断入口，包装 CLI.exe
  runtime/                        内置 Java 17 运行时
  app/SuperReaderWindows.jar

dist/windows/SuperReader-Windows-1.1.0-dev1.zip
  SuperReaderWindowsDev.exe
  SuperReaderWindowsCLI.exe
  ...
```

- 解压后双击 `SuperReaderWindows.exe`（开发版为 `SuperReaderWindowsDev.exe`），不需要另装 Java。
- 命令行：

```bat
SuperReaderWindows-console.bat --list-terminals
SuperReaderWindows-console.bat --read 0 --verbose
SuperReaderWindows-console.bat --selftest
```

`--selftest` 不访问硬件，只验证 TLV、PPSE、APDU 构造、AFL、金额、只读白名单与桥接 JSON 解析。当前 26 项全部通过。

## 只读边界

- 传输层硬编码 INS 白名单：`A4`（SELECT）、`B0`（READ BINARY）、`B2`（READ RECORD）、`C0`（GET RESPONSE）、`CA`（GET DATA）、`A8`（GPO）。
- `D6`（UPDATE BINARY）、`DA`（PUT DATA）、`E2`（APPEND RECORD）等写入类指令会在发送前被拒绝。
- 不发起支付、不产生交易、不写入任何文件。
- 普通预览版无网络代码、无联网权限；开发版只有手机桥接的局域网监听，且必须由用户手动开启。
- 卡号在界面上默认掩码（前 6 位 + 后 4 位）；原始 APDU 日志只保存在当前窗口内，关闭即丢失。

## 构建

要求 JDK 17（项目内自带 `.tools/jdk17`），无需 .NET、无需 WiX：

```powershell
cd windows
powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1 -Dev
```

或：

```bash
windows/build.sh
```

脚本会依次执行：编译 → 自检 → `jpackage --type app-image` → 生成 ZIP 与独立 JAR。开发版额外加入 `-Dsuperreader.dev=true`，并使用独立应用名与产物名。

产物：

```
dist/windows/SuperReader-Windows-1.1.0-preview2.zip
dist/windows/SuperReader-Windows-1.1.0-preview2.jar
dist/windows/SuperReader-Windows-1.1.0-dev1.zip
dist/windows/SuperReader-Windows-1.1.0-dev1.jar
```

`jpackage` 生成的是**免安装 app-image**，不是 MSI/EXE 安装器；没有代码签名，首次运行可能出现 SmartScreen 提示。正式分发需要 Authenticode 证书或商店签名。

## 项目结构

```
windows/
  src/main/java/com/superreader/windows/
    SuperReaderWindows.java   Swing UI、CLI、品牌样式、自检、手机读卡对话框
    PhoneBridgeClient.java    手机桥接 HTTP 客户端与 JSON 解析
    PcscService.java          PC/SC 连接、APDU 收发、只读白名单、读取编排
    EmvCard.java              PPSE/PDOL/AFL 解析、卡面摘要
    Tlv.java                  BER-TLV 与 APDU 构造
    Hex.java                  十六进制/Bcd/掩码
  assets/SuperReader.ico      应用图标
  build.ps1 / build.sh        构建与打包
```

## 已验证 / 未验证

已验证（本机，2026-10-31）：

- 编译通过；`--selftest` 26/26 通过（含桥接地址归一化与 JSON 解析）
- 预览版与开发版的版本号、应用名、ZIP 互不覆盖
- Android 开发版桥接端点在本机模拟器上通过 HTTP 验收：
  - 无配对码返回 401，错误配对码返回 401
  - `/status` 返回应用版本、只读标记与空闲状态
  - `/scan` 长轮询可进入等待、并发请求返回 409、超时返回 `timeout`
  - Windows `PhoneBridgeClient` 能识别错误配对码与超时
- 图形界面可在 150% 缩放的 2560×1600 桌面上完整显示（逻辑 920×680，物理 1380×1020）；无读卡器时为空状态
- 打包出的 app-image 可启动；ZIP 内含 GUI、CLI、内置运行时；独立 JAR 可运行
- 只读白名单拒绝 UPDATE BINARY / ERASE BINARY / PUT DATA

未验证（必须补）：

- **真实 PC/SC 读卡器 + 真实银行卡**上的 PPSE 选择、GPO、AFL 记录读取
- **真实 NFC 手机 + 真卡**上的手机桥接读取；当前只用模拟器验证了 HTTP 与认证，没有真实卡片投递
- 双标卡（银联 + Visa/万事达）多应用读取
- 卡片中途离开、读卡器拔出、驱动异常等错误路径
- 不同读卡器对短 APDU 与 PPSE 的兼容性
- 代码签名与 SmartScreen 行为
- 开发版对话框在 100%/125%/150%/200% 缩放下的布局

真卡验收清单：

1. 插读卡器，`--list-terminals` 能看到设备；放卡后显示“卡片在位”。
2. `--read --verbose` 能选择 PPSE，列出至少一个 AID。
3. 卡号掩码、有效期与卡面一致；电子现金余额与 Android 版对照一致（若有）。
4. 双标卡能看到两个应用，切换后 AID 与标签正确。
5. 抽卡后 GUI 自动断开；再次放卡可重新连接。
6. APDU 日志中不出现任何 `D6`/`DA`/`E2` 写入指令。
7. 与 Android 版读取同一张卡的公开字段逐项对照。
8. 开发版：手机桥接页面显示地址与配对码，电脑点「等待手机贴卡」后手机提示等待，贴卡后电脑收到脱敏文本，卡号已掩码。

## 已知限制

- 首个切片只做 EMV/PBOC；没有 BIN 库、没有交易日志、没有电子现金圈存日志。
- 桌面版只提供浅色主题。
- 如果卡片不支持 PPSE，且不在常见 AID 列表中，会显示“未发现可选择的应用”。
- 部分非接触读卡器需要厂商驱动；仅装 Windows 通用 CCID 驱动时可能无法枚举。
- 读卡器固件对短 APDU 的实现差异可能导致个别卡片 GPO 失败；失败时会回退探测记录并保留提示。
- 手机桥接要求手机应用保持前台，且电脑与手机在同一局域网；没有 mDNS 自动发现，需要手填地址。
- 无签名、无自动更新；版本更新需重新分发 ZIP。

## 数据与许可

- 程序不包含 Android 的 BIN 数据或卡产品名数据。
- 读到的卡数据只存在于内存，不落盘、不上传；手机桥接文本只显示在当前窗口。
- 本切片仅用于个人核验自己的卡片；请勿用于未授权的卡片读取或任何写卡用途。

@echo off
"%~dp0SuperReaderWindowsCLI.exe" %*
